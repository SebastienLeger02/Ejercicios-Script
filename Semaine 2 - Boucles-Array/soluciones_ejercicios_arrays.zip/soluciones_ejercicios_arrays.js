// EJERCICIO 1 (UTILIZANDO UN BUCLE FOR)
// Creamos el array con los números
let numeros = [1, 2, 3, 4, 5];

// Utilizamos un bucle `for`.
// Declaramos una variable `indice` que nos permite ir accediendo a cada índice del array
// NOTA: Fijaros que para incrementar el índice hacemos `indice++`, y no `indice = indice + 1`. El símbolo
// ++ nos permite incrementar una variable en una unidad de forma más corta y óptima
for (let indice = 0; indice < 5; indice++) {
  console.log(numeros[indice]);
}

// Mostramos los números
console.log(numeros[0]); // Número de la primera posición (índice 0)
console.log(numeros[2]); // Número de la tercera posición (índice 2)
console.log(numeros[3]); // Número de la cuarta posición (índice 3)

// EJERCICIO 1 (UTILIZANDO UN BUCLE WHILE)
// Creamos el array con los números
let numeros = [1, 2, 3, 4, 5];

// Utilizamos un bucle `while`.
// Declaramos de nuevo una variable `indice` que nos permite ir accediendo a cada índice del array
let indice = 0;
while (indice < 5) {
  console.log(numeros[indice]);
  indice++;
}

// Mostramos los números
console.log(numeros[0]); // Número de la primera posición (índice 0)
console.log(numeros[2]); // Número de la tercera posición (índice 2)
console.log(numeros[3]); // Número de la cuarta posición (índice 3)




// EJERCICIO 2 (UTILIZANDO UN BUCLE FOR)

// Creamos el array vacío
let nombres = [];

// Pedimos los 5 nombres con un bucle `for`, y los añadimos al array utilizando la función `push()`
for (let contador = 0; contador < 5; contador++) {
  let nombre = prompt("Introduce un nombre: ");
  nombres.push(nombre);
  console.log(nombres);
}

// Cambiamos el nombre del tercer índice  del array por "Pepito"
nombres[3] = "Pepito";

//Mostramos el array de nuevo para ver como queda con el nombre de "Pepito"
console.log(nombres);

// EJERCICIO 2 (UTILIZANDO UN BUCLE WHILE)

// Creamos el array vacío
let nombres = [];

// Pedimos los 5 nombres con un bucle `while`, y los añadimos al array utilizando la función `push()`
let contador = 0;
while(contador < 5) {
  let nombre = prompt("Introduce un nombre: ");
  nombres.push(nombre);
  console.log(nombres);
  contador++;
}

// Cambiamos el nombre del tercer índice  del array por "Pepito"
nombres[3] = "Pepito";

//Mostramos el array de nuevo para ver como queda con el nombre de "Pepito"
console.log(nombres);


// EJERCICIO 3 (UTILIZANDO UN BUCLE FOR)
// Creamos el array con los nombres de las asignaturas 
let asignaturas = ["mates", "lengua", "programación", "ingles", "naturales", "quimica"];
// Creamos el array con las notas de las asignaturas en sus respecivos indices (mates esta en el indice 0 del array `asignaturas`, 
// ponemos la nota de mates en el indice 0 del array `notas`, y asi sucesivamente)
let notas = [3, 9, 10, 7, 5, 6];


for (let indice = 0; indice < 6; indice++) {
  // Guardamos el valor de la nota en una variable auxiliar (podriamos seguir todo el rato con notas[indice], pero de esta forma es más corto y óptimo)
  let nota = notas[indice];

  if (nota < 5) {
    console.log("En", asignaturas[indice], "hemos suspendido");
  } else if (nota >= 5 && nota < 7) {
    console.log("En", asignaturas[indice], "hemos sacado un bien");
  } else if (nota >= 7 && nota < 9) {
    console.log("En", asignaturas[indice], "hemos sacado un muy bien");
  } else {
    console.log("En", asignaturas[indice], "hemos sacado un excelente");
  }
}

// EJERCICIO 3 (UTILIZANDO UN BUCLE WHILE)
// Creamos el array con los nombres de las asignaturas 
let asignaturas = ["mates", "lengua", "programación", "ingles", "naturales", "quimica"];
// Creamos el array con las notas de las asignaturas en sus respecivos indices (mates esta en el indice 0 del array `asignaturas`, 
// ponemos la nota de mates en el indice 0 del array `notas`, y asi sucesivamente)
let notas = [3, 9, 10, 7, 5, 6];

let indice = 0;
while(indice < 6) {
  // Guardamos el valor de la nota en una variable auxiliar (podriamos seguir todo el rato con notas[indice], pero de esta forma es más corto y óptimo)
  let nota = notas[indice];

  if (nota < 5) {
    console.log("En", asignaturas[indice], "hemos suspendido");
  } else if (nota >= 5 && nota < 7) {
    console.log("En", asignaturas[indice], "hemos sacado un bien");
  } else if (nota >= 7 && nota < 9) {
    console.log("En", asignaturas[indice], "hemos sacado un muy bien");
  } else {
    console.log("En", asignaturas[indice], "hemos sacado un excelente");
  }
  indice++;
}











