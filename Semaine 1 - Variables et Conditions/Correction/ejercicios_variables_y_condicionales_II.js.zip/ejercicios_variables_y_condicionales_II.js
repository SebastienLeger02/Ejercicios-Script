// EJERCICIO 1

// Pedimos la longitud de la casa y la guardamos en la variable `longitud`
let longitud = prompt("Introduce la longitud de la casa en metros:");
// Pedimos el ancho de la casa y la guardamos en la variable `ancho`
let ancho = prompt("Introduce el ancho de la casa en metros:");
// Calculamos el area de la casa (la formula para el area de la casa será longitud multiplicada por el ancho)
let area = longitud * ancho;
// Mostramos por pantalla el area de la casa
console.log("El área de la casa es: ",  area,  " metros cuadrados");


// EJERCICIO 2
/*
Para calcular el precio final, con el descuento aplicado podemos usar la siguiente fórmula:

precioFinal = precioInicial - (precioInicial * descuento)

Donde `precioInicial` es el precio del ordenador sin descuento, y `descuento` es el porcentaje de descuento que se aplica.

En este caso, tenemos:

Precio inicial: 400€
Descuento: 15% (en nuestro programa lo introduciremos como 0.15, ya que es lo mismo que el 15% de descuento)
Sustituyendo los valores en la fórmula:

precioFinal = 400 - (400 * 0.15)
precioFinal = 400 - 60
precioFinal = 340

Por lo tanto, el precio final con el 15% de descuento sería de 340€.

*/

let precioInicial = 400;
let descuento = 0.15;
let precioFinal = precioInicial - (precioInicial * descuento);

console.log("El precio final con descuento es de ", precioFinal, " euros");


// EJERCICIO 3
// Cambiar los valores de x e y para probar diferentes casos
let x = -5; 
let y = 3;

if (x > 0 && y > 0) {
  console.log("Las coordenadas ", x, "y" , y, " están en el primer cuadrante.");
} else if (x > 0 && y < 0) {
    console.log("Las coordenadas ", x, "y" , y, " están en el segundo cuadrante.");
} else if (x < 0 && y < 0) {
    console.log("Las coordenadas ", x, "y" , y, " están en el tercer cuadrante.");
} else if (x < 0 && y > 0) {
    console.log("Las coordenadas ", x, "y" , y, " están en el cuarto cuadrante.");
} else {
    // La última condición comprueba si los puntos están encima de los ejes (es decir, si `x` o `y` son 0)
    console.log("Las coordenadas ", x, "y" , y, " están en uno de los ejes.");
}
